<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    {{-- <link rel="icon" type="image/png" href="{{ asset('/favicon.png') }}"> --}}
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - {{ config('app.name', 'Laravel') }}</title>
    <!-- Font -->

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css" />
    <!-- Stylesheets -->

    <link href="{{ asset('public/assets/frontend/css/bootstrap.css') }}" rel="stylesheet">

    <link href="{{ asset('public/assets/frontend/css/swiper.css') }}" rel="stylesheet">

    <link href="{{ asset('public/assets/frontend/css/ionicons.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    @stack('css')

</head>
<body>
   {{-- <div class="container-fluid"> --}}
    @include('layouts.frontend.partial.header')

    @yield('content')
    
    @include('layouts.frontend.partial.footer')

{{-- </div> --}}
<!-- SCIPTS -->
<script src="{{ asset('public/assets/frontend/js/jquery-3.1.1.min.js') }}"></script>

<script src="{{ asset('public/assets/frontend/js/tether.min.js') }}"></script>

<script src="{{ asset('public/assets/frontend/js/bootstrap.js') }}"></script>
<script src="{{ asset('public/assets/frontend/js/swiper.js') }}"></script>
<script src="{{ asset('public/assets/frontend/js/scripts.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
{!! Toastr::message() !!}
<script>//laravel ar default validator message k tostr a show kora holo
    @if($errors->any())
    @foreach($errors->all() as $error)
        toastr.error('{{$error}}','Error',{
            closeButton:true,
            progressBar:true,
        })
    @endforeach
    @endif
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/62c56de97b967b11799849a5/1g79jamfe';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
@stack('js')
</body>
</html>